package com.capgemini.walletapp.ui;

import java.util.Scanner;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.bean.Wallet;
import com.capgemini.walletapp.exception.IWalletException;
import com.capgemini.walletapp.exception.WalletException;
import com.capgemini.walletapp.service.WalletApplicationService;

public class WalletApplicationMain {
	public static void main(String args[]) {
		int choice = 1;
		Scanner scr = new Scanner(System.in);
		WalletApplicationService service = new WalletApplicationService();

		System.out.println("\t\t *****PAYMENT BANK APPLICATION*****");
		do {
			System.out.println("1. CREATE ACCOUNT\n2. LOG IN\n3. EXIT");

			try {
				System.out.println("Enter your choice");
				choice = scr.nextInt();
				switch (choice) {
				case 1:
					Customer customer = new Customer();
					Wallet wallet = new Wallet();
					boolean b = false;

					System.out.println("Enter your name:");
					String customerName = scr.next();

					System.out.println("Enter your age:");
					int age = scr.nextInt();

					System.out.println("Enter your Phone Number:");
					String phoneNumber = scr.next();
					System.out.println("Enter your Aadhar Number:");
					long aadharNo = scr.nextLong();

					System.out.println("Enter your address:");
					String address = scr.next();

					System.out.println("Enter your Email:");
					String email = scr.next();

					System.out.println("Enter your Gender(Male/Female):");
					String gender = scr.next();

					double balance = 1000;
					System.out.println("Enter your User ID :");
					String user_ID = scr.next();
					System.out.println("Enter your password:");
					String password = scr.next();

					long accountNumber = (long) (Math.random() * 1000000000);
					customer.setAadharNumber(aadharNo);
					customer.setCustomerName(customerName);
					customer.setAge(age);
					customer.setAddress(address);
					customer.setPhoneNumber(phoneNumber);
					customer.setEmail(email);
					wallet.setAccountNumber(accountNumber);
					wallet.setAadharNumber(aadharNo);
					customer.setGender(gender);
					customer.setUser_ID(user_ID);
					customer.setPassword(password);
					wallet.setInitalBalance(balance);
					customer.setWallet(wallet);

					boolean result = true;
					if (result) {
						b = service.createAccount(customer);
					} else {
						System.out
								.println("Input is invalid(either phone number is incorrect or name shold not be null");
					}

					if (b) {
						System.out
								.println("Account Created Successfully  and your account number is: " + accountNumber);
					} else {
						try {
							throw new WalletException(IWalletException.ERROR4);
						} catch (WalletException e) {
							System.out.println("Account Creation is failed!!!!!!!!!");
						}
					}
					break;

				case 2:
					int choice1 = 1;
					boolean valid = false;
					System.out.println("Enter your UserId");
					String user_ID1 = scr.next();
					System.out.println("Enter your Password");
					String password1 = scr.next();
					valid = service.logIn(user_ID1, password1);
					if (valid) {
						do {
							System.out.println("Select any option:");
							System.out.println("1. SHOW BALANCE                           2.DEPOSIT      ");
							System.out.println("3. WITHDRAW                               4.FUND TRANSFER");
							System.out.println("5. PRINT TRANSCATION                      6.LOGOUT         ");
							System.out.println("Enter your choice");
							choice1 = scr.nextInt();
							switch (choice1) {
							case 1:
								double d = service.showBalance();
								System.out.println("Your Account Balance: " + d);
								break;
							case 2:
								double amt;
								System.out.println("Enter amount to deposite:");
								amt = scr.nextDouble();
								boolean b5 = service.deposite(amt);
								if (b5) {
									System.out.println("Amount deposited succesfully");
								} else {
									System.out.println("Failed to Deposite");
								}
								break;
							case 3:
								double amt1;
								System.out.println("Enter amount to withdraw:");
								amt1 = scr.nextDouble();
								boolean d1 = service.withdraw(amt1);
								if (d1) {
									System.out.println("Amount withdrawn succesfully");
								} else
									System.out.println("Failed to withdraw");
								break;

							case 4:
								long accnum;
								double amt2;
								System.out.println("Enetr Receiver Account Number");
								accnum = scr.nextLong();
								System.out.println("Enter amount to Transfer:");
								amt2 = scr.nextDouble();
								boolean b6 = service.fundTransfer(accnum, amt2);
								if (b6) {
									System.out.println("Your amount is transferred successfully!!");
								} else
									System.out.println("Transaction failed!!");
								break;

							case 5:
								service.printTranscation();
								break;
							case 6:
								System.out.println("Thank You!!");

								break;
							}
						} while (choice1 != 6);
					}

					else {
						System.out.println("Invalid choice!!");
					}
					break;
				case 3:
					System.out.println("ThankYou");
					System.exit(0);
					break;
				default:
					System.out.println("Enter correct choice");
					break;
				}
				System.out.println("**************************************************************************\n");
			} catch (NumberFormatException e1) {
				System.out.println(e1.getMessage());
			} catch (Exception e1) {
				System.out.println(e1.getMessage());
			}
		} while (choice != 3);
	}

}
