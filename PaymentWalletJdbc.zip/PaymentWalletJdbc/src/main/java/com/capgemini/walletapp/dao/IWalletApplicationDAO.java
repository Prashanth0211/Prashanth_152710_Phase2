package com.capgemini.walletapp.dao;

import java.util.List;

import java.util.Map;

import com.capgemini.walletapp.bean.Customer;
import com.capgemini.walletapp.exception.WalletException;

public interface IWalletApplicationDAO {

	public boolean createAccount(Customer customer);

	public double showBalance();

	public boolean deposite(double amount);

	public boolean logIn(String user_ID, String password);

	public boolean withdraw(double amount);

	public boolean fundTransfer(long receiverAccountNumber, double amount);

	public void printTranscation();

}
