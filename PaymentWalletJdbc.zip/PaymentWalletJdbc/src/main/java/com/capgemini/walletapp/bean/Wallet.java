package com.capgemini.walletapp.bean;

import java.time.LocalDate;

public class Wallet {
	private long accountNumber;
	private double initalBalance;
	private long aadharNumber;
	private LocalDate date;
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getInitalBalance() {
		return initalBalance;
	}
	public void setInitalBalance(double initalBalance) {
		this.initalBalance = initalBalance;
	}
	public long getAadharNumber() {
		return aadharNumber;
	}
	public void setAadharNumber(long aadharNumber) {
		this.aadharNumber = aadharNumber;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "Wallet [accountNumber=" + accountNumber + ", initalBalance=" + initalBalance + ", aadharNumber="
				+ aadharNumber + ", date=" + date + "]";
	}
	
}
